# Regional Media Feedback AI-ML System

An end-to-end NLP pipeline to collect, preprocess, analyze, and visualize **regional media feedback** (news headlines, posts, comments) across multiple Indian languages.

## ✨ Features
- Multilingual text handling (English + examples in Hindi, Tamil, Telugu, Kannada).
- Sentiment Analysis: Positive / Neutral / Negative.
- Topic Classification: Politics, Sports, Entertainment, Business, Technology (customizable).
- Classical ML baseline (Logistic Regression + TF-IDF) and BERT-ready hooks.
- Streamlit demo app for quick evaluation.
- Modular code: preprocessing, training, inference, and simple dashboard.

## 🗂️ Repository Structure
```
Regional-Media-Feedback-AI-ML-System/
├── docs/
├── data/
├── results/
└── src/
```
See inline READMEs for details.

## 🚀 Getting Started

### 1) Create environment & install dependencies
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
```

### 2) Train models
```bash
python src/train_model.py --task sentiment --data data/sample_dataset.csv --out results
python src/train_model.py --task topic --data data/sample_dataset.csv --out results
```

### 3) Run Streamlit app
```bash
streamlit run src/app.py
```

### 4) Inference with CLI
```bash
python src/sentiment_analysis.py --text "The new policy is excellent for farmers"
python src/topic_classification.py --text "கிரிக்கெட் போட்டி மிக அருமை"
```

## 📦 Data
A small multilingual sample is in `data/sample_dataset.csv`. Replace with your own, keeping columns:
- `id, text, language, sentiment, topic`

## 🧪 Evaluation
Training script saves metrics and artifacts to `results/`:
- `*_model.joblib` – trained model
- `*_vectorizer.joblib` – TF-IDF vectorizer
- `*_metrics.json` – accuracy, f1-score
- `confusion_matrix_*.png`, `accuracy_curve_*.png` – visuals

## 🧱 Architecture
- `src/preprocessing.py` – cleaning, normalization, language hints
- `src/train_model.py` – training pipeline for sentiment/topic
- `src/sentiment_analysis.py` – load-and-predict for sentiment
- `src/topic_classification.py` – load-and-predict for topics
- `src/app.py` – Streamlit UI

## 🔧 Customize
- Update labels (`SENTIMENT_LABELS`, `TOPIC_LABELS`) in `train_model.py`.
- Plug in a transformer by installing `transformers` and enabling the stub in code.

## 📜 License
MIT – see `LICENSE`.

## 👤 Authors
- Your Team Name
- Guide & Coordinator: *Add names here*

## ✅ Submission
After review, upload this repo to a **public GitHub repository** and share the URL with the **Guide** and **Project Coordinator**.
