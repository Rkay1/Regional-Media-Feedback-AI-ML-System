# sentiment_analysis.py
import argparse
import joblib
from preprocessing import preprocess_corpus

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="results/sentiment_model.joblib")
    ap.add_argument("--text", required=True)
    args = ap.parse_args()

    pipe = joblib.load(args.model)
    X = preprocess_corpus([args.text])
    pred = pipe.predict(X)[0]
    proba = None
    try:
        proba = pipe.predict_proba(X)[0]
    except Exception:
        pass
    print({"prediction": pred, "proba": proba.tolist() if proba is not None else None})

if __name__ == "__main__":
    main()
