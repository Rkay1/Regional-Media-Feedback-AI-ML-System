# app.py
import streamlit as st
import joblib
from preprocessing import preprocess_corpus

st.set_page_config(page_title="Regional Media Feedback AI-ML", layout="wide")

st.title("📰 Regional Media Feedback AI-ML System")
st.write("Analyze sentiment and topic for regional media text.")

col1, col2 = st.columns(2)

with col1:
    st.subheader("Sentiment")
    sentiment_model_path = st.text_input("Sentiment model path", "results/sentiment_model.joblib")
    text_input_s = st.text_area("Enter text", "The new policy helped farmers.")
    if st.button("Predict Sentiment"):
        try:
            model = joblib.load(sentiment_model_path)
            X = preprocess_corpus([text_input_s])
            pred = model.predict(X)[0]
            st.success(f"Prediction: **{pred}**")
        except Exception as e:
            st.error(f"Error: {e}")

with col2:
    st.subheader("Topic")
    topic_model_path = st.text_input("Topic model path", "results/topic_model.joblib")
    text_input_t = st.text_area("Enter text ", "கிரிக்கெட் போட்டி அருமை")
    if st.button("Predict Topic"):
        try:
            model = joblib.load(topic_model_path)
            X = preprocess_corpus([text_input_t])
            pred = model.predict(X)[0]
            st.success(f"Prediction: **{pred}**")
        except Exception as e:
            st.error(f"Error: {e}")

st.info("Tip: Train models first using `python src/train_model.py --task sentiment/topic --data data/sample_dataset.csv --out results`.")
