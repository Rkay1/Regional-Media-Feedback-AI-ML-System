# preprocessing.py
import re
import unicodedata
from typing import List, Optional
try:
    from langdetect import detect
except Exception:
    detect = None

URL_RE = re.compile(r"https?://\S+|www\.\S+")
MENTION_RE = re.compile(r"@\w+")
HASHTAG_RE = re.compile(r"#\w+")

def normalize_text(text: str, lang_hint: Optional[str] = None) -> str:
    if not isinstance(text, str):
        return ""
    t = unicodedata.normalize("NFKC", text)
    t = URL_RE.sub(" ", t)
    t = MENTION_RE.sub(" ", t)
    t = HASHTAG_RE.sub(" ", t)
    t = t.strip()
    # Lowercase only for Latin-script; keep as-is for others
    if re.search(r"[A-Za-z]", t):
        t = t.lower()
    t = re.sub(r"\s+", " ", t)
    return t

def detect_lang(text: str) -> str:
    if detect is None:
        return "xx"
    try:
        return detect(text)
    except Exception:
        return "xx"

def preprocess_corpus(texts: List[str], lang_hints: Optional[List[str]] = None) -> List[str]:
    cleaned = []
    for i, t in enumerate(texts):
        hint = None
        if lang_hints and i < len(lang_hints):
            hint = lang_hints[i]
        cleaned.append(normalize_text(t, hint))
    return cleaned
