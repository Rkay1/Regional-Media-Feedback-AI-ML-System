# train_model.py
import argparse
import os
import json
import joblib
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score, confusion_matrix, classification_report
from sklearn.pipeline import Pipeline
import matplotlib.pyplot as plt

from preprocessing import preprocess_corpus

SENTIMENT_LABELS = ["Negative", "Neutral", "Positive"]
TOPIC_LABELS = ["Politics", "Sports", "Entertainment", "Business", "Technology"]

def plot_confusion(cm, labels, out_path):
    fig = plt.figure()
    im = plt.imshow(cm, interpolation='nearest')
    plt.title('Confusion Matrix')
    plt.colorbar(im)
    tick_marks = np.arange(len(labels))
    plt.xticks(tick_marks, labels, rotation=45, ha="right")
    plt.yticks(tick_marks, labels)
    plt.tight_layout()
    plt.ylabel('True label')
    plt.xlabel('Predicted label')
    fig.savefig(out_path, bbox_inches="tight")
    plt.close(fig)

def train_task(df, text_col, label_col, out_dir, model_name):
    X = preprocess_corpus(df[text_col].fillna("").tolist(), df.get("language"))
    y = df[label_col].astype(str).tolist()

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

    pipe = Pipeline([
        ("tfidf", TfidfVectorizer(max_features=20000, ngram_range=(1,2))),
        ("clf", LogisticRegression(max_iter=200))
    ])
    pipe.fit(X_train, y_train)

    y_pred = pipe.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred, average="weighted")

    os.makedirs(out_dir, exist_ok=True)
    joblib.dump(pipe, os.path.join(out_dir, f"{model_name}_model.joblib"))

    # Metrics
    metrics = {
        "accuracy": acc,
        "f1_weighted": f1,
        "labels": sorted(list(set(y)))
    }
    with open(os.path.join(out_dir, f"{model_name}_metrics.json"), "w", encoding="utf-8") as f:
        json.dump(metrics, f, indent=2)

    # Confusion matrix
    cm = confusion_matrix(y_test, y_pred, labels=metrics["labels"])
    plot_confusion(cm, metrics["labels"], os.path.join(out_dir, f"confusion_matrix_{model_name}.png"))

    print(json.dumps(metrics, indent=2))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--task", choices=["sentiment", "topic"], required=True)
    ap.add_argument("--data", required=True, help="Path to CSV with id,text,language,sentiment,topic")
    ap.add_argument("--out", default="results")
    args = ap.parse_args()

    df = pd.read_csv(args.data)

    if args.task == "sentiment":
        train_task(df, "text", "sentiment", args.out, "sentiment")
    else:
        train_task(df, "text", "topic", args.out, "topic")

if __name__ == "__main__":
    main()
