# Data README

- `sample_dataset.csv` is a tiny illustrative dataset for both sentiment and topic tasks.
- Replace it with a larger, real dataset for meaningful results.
- Required columns: `id, text, language, sentiment, topic`.
