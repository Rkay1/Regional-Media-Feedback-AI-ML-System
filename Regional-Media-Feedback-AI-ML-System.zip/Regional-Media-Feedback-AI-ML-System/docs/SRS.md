# Software Requirements Specification (SRS)

## 1. Purpose
Specify functional and non-functional requirements for the Regional Media Feedback AI-ML System.

## 2. Scope
Analyze multilingual short text for sentiment and topic; provide training, inference, and a simple UI.

## 3. Functional Requirements
- FR1: Upload CSV dataset with columns `id, text, language, sentiment, topic`.
- FR2: Train models for sentiment and topic.
- FR3: Predict sentiment/topic for ad-hoc text inputs.
- FR4: Visualize metrics and confusion matrices.
- FR5: Save and load models and vectorizers.

## 4. Non-Functional Requirements
- NFR1: Reproducible builds via `requirements.txt`.
- NFR2: Usable on modest hardware (TF-IDF baselines).
- NFR3: Extensible to transformers.
- NFR4: Simple web UI via Streamlit.

## 5. Users & Roles
- Analyst/Student: run training, explore results.
- Reviewer/Guide: review README, docs, and sample runs.

## 6. System Features
- Data preprocessing, feature extraction, model training, inference, and visualization.

## 7. Constraints
- Quality limited by dataset size and label quality.
- Internet not required unless scraping or transformer downloads are enabled.

## 8. Assumptions & Dependencies
- Python 3.10+, scikit-learn stack, Streamlit.
