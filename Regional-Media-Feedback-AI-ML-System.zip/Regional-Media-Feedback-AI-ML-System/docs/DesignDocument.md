# Design Document

## 1. Architecture
Layers: Data -> Preprocessing -> Features -> Models -> Evaluation -> App UI.

## 2. Key Components
- `preprocessing.py`: cleaners, normalizers, language detection wrapper.
- `train_model.py`: end-to-end training with CLI flags.
- `sentiment_analysis.py` / `topic_classification.py`: inference scripts.
- `app.py`: Streamlit interface.

## 3. Data Model
CSV with `id (int)`, `text (str)`, `language (str, ISO-ish)`, `sentiment (str)`, `topic (str)`.

## 4. Sequence (Training)
```mermaid
sequenceDiagram
participant U as User
participant T as train_model.py
participant P as preprocessing
participant M as Model
U->>T: run with CSV path and task
T->>P: preprocess text
P-->>T: cleaned text
T->>M: fit TF-IDF + classifier
M-->>T: metrics, artifacts
T-->>U: files in /results
```

## 5. Extensibility
- Swap TF-IDF with transformer embeddings.
- Add languages via custom normalizers.
- Add tasks (e.g., stance detection, NER).
