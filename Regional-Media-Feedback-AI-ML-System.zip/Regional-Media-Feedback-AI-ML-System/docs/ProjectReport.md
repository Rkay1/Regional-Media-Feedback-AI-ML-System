# Project Report: Regional Media Feedback AI-ML System

## 1. Introduction
Regional media reflects localized public opinion. Extracting insights across languages is challenging due to code-mixing, transliteration, and dialectal variance. This project builds an end-to-end pipeline for collecting, preprocessing, analyzing, and visualizing regional media feedback.

## 2. Problem Statement
Given short text from news or social media in Indian languages, classify **sentiment** and **topic** reliably with transparent baselines and an easy-to-use demo.

## 3. Objectives
- Handle multilingual text (English + regional languages).
- Build baseline models for sentiment and topic.
- Provide visual analytics and a web demo.
- Offer reproducible training and evaluation.

## 4. Literature Review (brief)
- Traditional ML with TF-IDF remains a strong baseline for short-text classification.
- Transformer models (mBERT, IndicBERT) improve cross-lingual performance but need more compute.
- Preprocessing (normalization, punctuation handling) is essential in code-mixed data.

## 5. System Architecture
```mermaid
flowchart LR
A[Data Sources] --> B[Preprocessing]
B --> C[Feature Extraction (TF-IDF)]
C --> D1[Sentiment Model]
C --> D2[Topic Model]
D1 --> E[Metrics + Artifacts]
D2 --> E
E --> F[Streamlit App]
```
Modules: data ingestion, preprocessing, feature extraction, model training, evaluation, and UI.

## 6. Methodology
### 6.1 Data
Columns: `id, text, language, sentiment, topic`. Labels use small curated examples, expandable with your own data.

### 6.2 Preprocessing
- Unicode normalization, lowercasing (language-aware), URL/handle removal.
- Optional language detection for unknown language codes.
- Tokenization via simple regex; extensible to Indic NLP toolkits.

### 6.3 Models
- Baseline: TF-IDF (word-level) + Logistic Regression.
- Alternatives: Linear SVM, Random Forest.
- Optional: Transformers (mBERT/IndicBERT) – stub included for extension.

### 6.4 Evaluation
Train/validation split with accuracy/F1; confusion matrices and curves plotted to `results/`.

## 7. Implementation
Python 3.10+, scikit-learn, pandas, joblib, matplotlib, streamlit, wordcloud.

## 8. Results (sample)
Baseline models on the tiny sample dataset achieve high variance; real performance depends on data size/quality. Replace `data/sample_dataset.csv` with a larger labeled dataset for meaningful metrics.

## 9. Use Cases
- Media monitoring for local governance.
- Brand and campaign tracking at the state/district level.
- Academic projects on multilingual NLP.

## 10. Limitations & Future Work
- Limited training data; add more annotated examples.
- Add transformer-based multilingual models.
- Improve tokenization for code-mixed, transliterated text.
- Add named entity recognition and stance detection.

## 11. Conclusion
A practical, modular baseline for multilingual regional media feedback analysis with an interactive demo and clear extension path.
